package com.example.firstactivityand

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    /*
    NOME:HEITOR COSTA RIBEIRO
    MATRÍCULA:22000950
    NÚMERO:24
     */


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var editAge = findViewById<EditText>(R.id.editAge)
        var btnCalculator = findViewById<Button>(R.id.btnCalculator)





        btnCalculator.setOnClickListener{
            Toast.makeText(this,"Sua Idade de cachorro é:" , Toast.LENGTH_LONG).show()
        }

    }
}
